# Installation Guide - FoodieExpress

This guide will help you set up the FoodieExpress food delivery platform on your local machine or server.

## System Requirements

### Minimum Requirements
- **Operating System**: Windows 10, macOS 10.14, or Ubuntu 18.04+
- **Node.js**: Version 16.0 or higher
- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 2GB free space
- **Internet**: Stable internet connection for package downloads

### Recommended Requirements
- **Node.js**: Version 18.0 or higher
- **RAM**: 8GB or more
- **Storage**: 5GB free space
- **Database**: MongoDB 5.0+ (local or cloud)

## Pre-Installation Setup

### 1. Install Node.js
Download and install Node.js from [nodejs.org](https://nodejs.org/)

Verify installation:
```bash
node --version
npm --version
```

### 2. Install MongoDB (Optional - for local development)
- **Option A**: Install MongoDB locally from [mongodb.com](https://www.mongodb.com/try/download/community)
- **Option B**: Use MongoDB Atlas (cloud) - recommended for production

### 3. Install Git
Download and install Git from [git-scm.com](https://git-scm.com/)

## Installation Steps

### Step 1: Download the Project
Extract the provided zip file to your desired location:
```bash
unzip food-delivery-platform.zip
cd food-delivery-platform
```

### Step 2: Backend Setup

1. **Navigate to backend directory**
   ```bash
   cd backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Create environment configuration**
   ```bash
   cp .env.example .env
   ```

4. **Configure environment variables**
   Edit the `.env` file with your settings:
   ```env
   # Database Configuration
   MONGODB_URI=mongodb://localhost:27017/fooddelivery
   # For MongoDB Atlas: mongodb+srv://username:password@cluster.mongodb.net/fooddelivery
   
   # JWT Configuration
   JWT_SECRET=your-super-secret-jwt-key-here
   JWT_EXPIRE=30d
   
   # Server Configuration
   NODE_ENV=development
   PORT=5000
   
   # Rate Limiting
   RATE_LIMIT_WINDOW=15
   RATE_LIMIT_MAX_REQUESTS=100
   
   # Email Configuration (Optional)
   EMAIL_FROM=noreply@foodieexpress.com
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_EMAIL=your-email@gmail.com
   SMTP_PASSWORD=your-app-password
   
   # Payment Configuration (Optional)
   STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
   STRIPE_PUBLISHABLE_KEY=pk_test_your_stripe_publishable_key
   ```

### Step 3: Frontend Setup

1. **Navigate to frontend directory**
   ```bash
   cd ../frontend/food-delivery-frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure API endpoint (if needed)**
   The frontend is configured to connect to `http://localhost:5000/api` by default.
   If your backend runs on a different port, update `src/services/api.js`:
   ```javascript
   const api = axios.create({
     baseURL: 'http://localhost:YOUR_PORT/api',
     // ... other config
   });
   ```

## Running the Application

### Development Mode

1. **Start MongoDB** (if using local installation)
   ```bash
   # On Windows
   net start MongoDB
   
   # On macOS/Linux
   sudo systemctl start mongod
   # or
   brew services start mongodb/brew/mongodb-community
   ```

2. **Start the backend server**
   ```bash
   cd backend
   npm start
   ```
   The backend will run on http://localhost:5000

3. **Start the frontend development server**
   ```bash
   cd frontend/food-delivery-frontend
   npm run dev
   ```
   The frontend will run on http://localhost:5173

4. **Access the application**
   Open your browser and navigate to http://localhost:5173

### Production Mode

1. **Build the frontend**
   ```bash
   cd frontend/food-delivery-frontend
   npm run build
   ```

2. **Start the backend in production mode**
   ```bash
   cd backend
   NODE_ENV=production npm start
   ```

## Verification

### 1. Backend Health Check
Visit http://localhost:5000/api/health in your browser. You should see:
```json
{
  "message": "Food Delivery API is running!",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "environment": "development"
}
```

### 2. Frontend Application
Visit http://localhost:5173 and verify:
- [ ] Homepage loads correctly
- [ ] Navigation menu is functional
- [ ] Restaurant listings are displayed
- [ ] Login/Register forms work
- [ ] No console errors in browser developer tools

### 3. Database Connection
Check the backend console for:
```
MongoDB Connected: localhost:27017
Server running in development mode on port 5000
```

## Troubleshooting

### Common Issues

#### 1. Port Already in Use
**Error**: `EADDRINUSE: address already in use :::5000`
**Solution**: 
- Kill the process using the port: `npx kill-port 5000`
- Or change the port in `.env` file

#### 2. MongoDB Connection Failed
**Error**: `MongoNetworkError: connect ECONNREFUSED`
**Solutions**:
- Ensure MongoDB is running
- Check the MONGODB_URI in `.env`
- For MongoDB Atlas, verify network access and credentials

#### 3. Module Not Found
**Error**: `Cannot find module 'xyz'`
**Solution**: 
```bash
rm -rf node_modules package-lock.json
npm install
```

#### 4. Permission Denied (Linux/macOS)
**Error**: `EACCES: permission denied`
**Solution**:
```bash
sudo chown -R $(whoami) ~/.npm
```

#### 5. Frontend Build Fails
**Error**: Build process fails
**Solutions**:
- Clear cache: `npm run clean` or `rm -rf .vite`
- Update dependencies: `npm update`
- Check for TypeScript errors

### Performance Issues

#### Slow Loading
- Ensure you have sufficient RAM (8GB recommended)
- Close unnecessary applications
- Use SSD storage if possible

#### Database Performance
- Index frequently queried fields
- Use MongoDB Compass for query optimization
- Consider upgrading to MongoDB Atlas for better performance

## Environment-Specific Setup

### Windows
```bash
# Use PowerShell or Command Prompt
# Install Node.js from nodejs.org
# Install MongoDB Community Server
# Use npm commands as shown above
```

### macOS
```bash
# Install using Homebrew (recommended)
brew install node
brew install mongodb/brew/mongodb-community
brew services start mongodb/brew/mongodb-community
```

### Linux (Ubuntu/Debian)
```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install MongoDB
wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/5.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-5.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org
sudo systemctl start mongod
```

## Next Steps

After successful installation:

1. **Create Admin Account**: Register the first user account
2. **Add Sample Data**: Use the provided seed scripts (if available)
3. **Configure Payment**: Set up Stripe or other payment providers
4. **Email Setup**: Configure SMTP for notifications
5. **Security**: Review and update security settings for production

## Support

If you encounter issues during installation:

1. Check the troubleshooting section above
2. Review the logs in the console
3. Ensure all prerequisites are met
4. Contact support with detailed error messages

## Security Notes

- Change default JWT_SECRET in production
- Use environment variables for sensitive data
- Enable HTTPS in production
- Regularly update dependencies
- Use strong passwords for database access

---

**Installation complete!** You're now ready to use FoodieExpress.

