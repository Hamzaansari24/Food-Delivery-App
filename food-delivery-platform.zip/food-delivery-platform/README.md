# FoodieExpress - Food Delivery Platform

A comprehensive food delivery platform built with the MERN stack, featuring restaurant listings, menu browsing, order tracking, secure payments, delivery scheduling, and customer feedback.

## 🚀 Features

### For Customers
- **User Authentication**: Secure registration and login system
- **Restaurant Discovery**: Browse restaurants by cuisine, location, and ratings
- **Menu Browsing**: Detailed menu with categories, descriptions, and pricing
- **Shopping Cart**: Add/remove items with quantity management
- **Secure Checkout**: Multiple payment options and delivery scheduling
- **Order Tracking**: Real-time order status updates
- **Customer Reviews**: Rate and review restaurants and delivery experience
- **Profile Management**: Manage personal information and order history

### For Restaurants
- **Restaurant Profiles**: Create and manage restaurant information
- **Menu Management**: Add, edit, and organize menu items
- **Order Management**: Receive and process customer orders
- **Analytics Dashboard**: Track sales and customer feedback

### For Delivery Drivers
- **Order Assignment**: Receive delivery assignments
- **Route Optimization**: Efficient delivery route planning
- **Status Updates**: Update delivery status in real-time

## 🛠️ Tech Stack

### Frontend
- **React 18** - Modern UI library with hooks
- **React Router** - Client-side routing
- **TailwindCSS** - Utility-first CSS framework
- **Shadcn/UI** - High-quality component library
- **Lucide Icons** - Beautiful icon set
- **React Query** - Data fetching and caching
- **Axios** - HTTP client for API calls

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web application framework
- **MongoDB** - NoSQL database
- **Mongoose** - MongoDB object modeling
- **JWT** - JSON Web Tokens for authentication
- **bcryptjs** - Password hashing
- **Express Validator** - Input validation
- **CORS** - Cross-origin resource sharing
- **Helmet** - Security middleware

### Development Tools
- **Vite** - Fast build tool and development server
- **ESLint** - Code linting
- **Prettier** - Code formatting
- **Nodemon** - Auto-restart development server

## 📁 Project Structure

```
food-delivery-platform/
├── backend/
│   ├── models/           # Database models
│   ├── routes/           # API routes
│   ├── middleware/       # Custom middleware
│   ├── utils/           # Utility functions
│   ├── uploads/         # File uploads
│   ├── config/          # Configuration files
│   ├── server.js        # Main server file
│   └── package.json     # Backend dependencies
├── frontend/
│   ├── src/
│   │   ├── components/  # Reusable components
│   │   ├── pages/       # Page components
│   │   ├── context/     # React context
│   │   ├── services/    # API services
│   │   ├── hooks/       # Custom hooks
│   │   └── utils/       # Utility functions
│   ├── public/          # Static assets
│   └── package.json     # Frontend dependencies
└── README.md           # Project documentation
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v16 or higher)
- MongoDB (local or cloud instance)
- npm or yarn package manager

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd food-delivery-platform
   ```

2. **Backend Setup**
   ```bash
   cd backend
   npm install
   
   # Create environment file
   cp .env.example .env
   
   # Update .env with your configuration
   # MONGODB_URI=mongodb://localhost:27017/fooddelivery
   # JWT_SECRET=your-secret-key
   # NODE_ENV=development
   ```

3. **Frontend Setup**
   ```bash
   cd ../frontend/food-delivery-frontend
   npm install
   ```

### Running the Application

1. **Start MongoDB** (if running locally)
   ```bash
   mongod
   ```

2. **Start Backend Server**
   ```bash
   cd backend
   npm start
   # Server runs on http://localhost:5000
   ```

3. **Start Frontend Development Server**
   ```bash
   cd frontend/food-delivery-frontend
   npm run dev
   # Application runs on http://localhost:5173
   ```

4. **Access the Application**
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:5000/api

## 📱 Usage

### Customer Journey
1. **Registration/Login**: Create account or sign in
2. **Browse Restaurants**: Explore available restaurants
3. **Select Restaurant**: View menu and restaurant details
4. **Add to Cart**: Select items and customize orders
5. **Checkout**: Enter delivery details and payment information
6. **Track Order**: Monitor order status in real-time
7. **Rate & Review**: Provide feedback after delivery

### Restaurant Owner Journey
1. **Register Business**: Create restaurant profile
2. **Setup Menu**: Add categories and menu items
3. **Manage Orders**: Process incoming orders
4. **Update Status**: Keep customers informed
5. **View Analytics**: Track performance metrics

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/profile` - Get user profile

### Restaurants
- `GET /api/restaurants` - Get all restaurants
- `GET /api/restaurants/:id` - Get restaurant details
- `POST /api/restaurants` - Create restaurant (owner)
- `PUT /api/restaurants/:id` - Update restaurant (owner)

### Orders
- `POST /api/orders` - Create new order
- `GET /api/orders` - Get user orders
- `GET /api/orders/:id` - Get order details
- `PATCH /api/orders/:id/status` - Update order status

### Reviews
- `POST /api/reviews` - Create review
- `GET /api/reviews/restaurant/:id` - Get restaurant reviews

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: bcrypt for secure password storage
- **Input Validation**: Comprehensive input sanitization
- **Rate Limiting**: API rate limiting to prevent abuse
- **CORS Protection**: Configured cross-origin resource sharing
- **Helmet Security**: Security headers for protection

## 🎨 UI/UX Features

- **Responsive Design**: Mobile-first approach
- **Dark/Light Mode**: Theme switching capability
- **Loading States**: Smooth loading indicators
- **Error Handling**: User-friendly error messages
- **Form Validation**: Real-time form validation
- **Accessibility**: WCAG compliant components

## 🧪 Testing

### Frontend Testing
```bash
cd frontend/food-delivery-frontend
npm run test
```

### Backend Testing
```bash
cd backend
npm run test
```

## 📦 Deployment

### Frontend Deployment
```bash
cd frontend/food-delivery-frontend
npm run build
# Deploy dist/ folder to your hosting service
```

### Backend Deployment
```bash
cd backend
# Set production environment variables
# Deploy to your hosting service (Heroku, AWS, etc.)
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👥 Team

- **Frontend Development**: React.js, TailwindCSS, UI/UX Design
- **Backend Development**: Node.js, Express.js, MongoDB
- **DevOps**: Deployment, CI/CD, Monitoring

## 🆘 Support

For support, email support@foodieexpress.com or join our Slack channel.

## 🔮 Future Enhancements

- **Real-time Chat**: Customer support chat
- **Push Notifications**: Order updates via push notifications
- **Advanced Analytics**: Detailed business intelligence
- **Multi-language Support**: Internationalization
- **Mobile App**: Native iOS and Android applications
- **AI Recommendations**: Personalized food recommendations
- **Loyalty Program**: Customer rewards system

## 📊 Performance

- **Page Load Time**: < 2 seconds
- **API Response Time**: < 500ms
- **Mobile Performance**: 90+ Lighthouse score
- **SEO Optimization**: Structured data and meta tags

---

**Built with ❤️ by the FoodieExpress Team**

