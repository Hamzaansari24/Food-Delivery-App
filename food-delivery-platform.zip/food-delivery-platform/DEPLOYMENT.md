# Deployment Guide - FoodieExpress

This guide covers deploying the FoodieExpress food delivery platform to production environments.

## Deployment Options

### 1. Cloud Platforms (Recommended)
- **Vercel** (Frontend) + **Railway/Heroku** (Backend)
- **Netlify** (Frontend) + **AWS/DigitalOcean** (Backend)
- **AWS** (Full stack)
- **Google Cloud Platform** (Full stack)
- **Microsoft Azure** (Full stack)

### 2. VPS/Dedicated Servers
- **DigitalOcean Droplets**
- **Linode**
- **Vultr**
- **AWS EC2**

## Pre-Deployment Checklist

- [ ] Environment variables configured
- [ ] Database setup (MongoDB Atlas recommended)
- [ ] Domain name registered
- [ ] SSL certificate ready
- [ ] Payment gateway configured
- [ ] Email service configured
- [ ] Error monitoring setup

## Frontend Deployment

### Option 1: Vercel (Recommended)

1. **Build the application**
   ```bash
   cd frontend/food-delivery-frontend
   npm run build
   ```

2. **Deploy to Vercel**
   ```bash
   npm install -g vercel
   vercel --prod
   ```

3. **Configure environment variables in Vercel dashboard**
   - `VITE_API_URL=https://your-backend-domain.com/api`

### Option 2: Netlify

1. **Build the application**
   ```bash
   cd frontend/food-delivery-frontend
   npm run build
   ```

2. **Deploy to Netlify**
   - Drag and drop the `dist` folder to Netlify
   - Or connect your Git repository

3. **Configure redirects**
   Create `public/_redirects`:
   ```
   /*    /index.html   200
   ```

### Option 3: AWS S3 + CloudFront

1. **Build the application**
   ```bash
   npm run build
   ```

2. **Upload to S3**
   ```bash
   aws s3 sync dist/ s3://your-bucket-name --delete
   ```

3. **Configure CloudFront distribution**
   - Set origin to S3 bucket
   - Configure custom error pages for SPA routing

## Backend Deployment

### Option 1: Railway (Recommended)

1. **Connect your repository to Railway**
2. **Configure environment variables**
3. **Deploy automatically on push**

### Option 2: Heroku

1. **Install Heroku CLI**
   ```bash
   npm install -g heroku
   ```

2. **Login and create app**
   ```bash
   heroku login
   heroku create your-app-name
   ```

3. **Configure environment variables**
   ```bash
   heroku config:set NODE_ENV=production
   heroku config:set MONGODB_URI=your-mongodb-uri
   heroku config:set JWT_SECRET=your-jwt-secret
   ```

4. **Deploy**
   ```bash
   git push heroku main
   ```

### Option 3: DigitalOcean App Platform

1. **Connect your repository**
2. **Configure build and run commands**
   - Build: `npm install`
   - Run: `npm start`
3. **Set environment variables**
4. **Deploy**

### Option 4: VPS/Server Deployment

1. **Server setup**
   ```bash
   # Update system
   sudo apt update && sudo apt upgrade -y
   
   # Install Node.js
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   
   # Install PM2
   sudo npm install -g pm2
   
   # Install Nginx
   sudo apt install nginx -y
   ```

2. **Deploy application**
   ```bash
   # Clone repository
   git clone your-repository-url
   cd food-delivery-platform/backend
   
   # Install dependencies
   npm install --production
   
   # Start with PM2
   pm2 start server.js --name "foodie-backend"
   pm2 startup
   pm2 save
   ```

3. **Configure Nginx**
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;
       
       location / {
           proxy_pass http://localhost:5000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

4. **SSL with Let's Encrypt**
   ```bash
   sudo apt install certbot python3-certbot-nginx
   sudo certbot --nginx -d your-domain.com
   ```

## Database Deployment

### MongoDB Atlas (Recommended)

1. **Create cluster**
   - Sign up at [mongodb.com/atlas](https://www.mongodb.com/atlas)
   - Create a new cluster
   - Choose your preferred region

2. **Configure security**
   - Add IP addresses to whitelist
   - Create database user
   - Generate connection string

3. **Update environment variables**
   ```env
   MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/fooddelivery?retryWrites=true&w=majority
   ```

### Self-hosted MongoDB

1. **Install MongoDB on server**
   ```bash
   wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -
   echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/5.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-5.0.list
   sudo apt-get update
   sudo apt-get install -y mongodb-org
   ```

2. **Configure MongoDB**
   ```bash
   sudo systemctl start mongod
   sudo systemctl enable mongod
   ```

3. **Secure MongoDB**
   ```bash
   mongo
   use admin
   db.createUser({
     user: "admin",
     pwd: "secure-password",
     roles: ["userAdminAnyDatabase"]
   })
   ```

## Environment Configuration

### Production Environment Variables

**Backend (.env)**
```env
NODE_ENV=production
PORT=5000
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/fooddelivery
JWT_SECRET=super-secure-jwt-secret-key
JWT_EXPIRE=30d

# CORS
CORS_ORIGIN=https://your-frontend-domain.com

# Rate Limiting
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX_REQUESTS=100

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_EMAIL=your-email@gmail.com
SMTP_PASSWORD=your-app-password

# Payment
STRIPE_SECRET_KEY=sk_live_your_stripe_secret_key
STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable_key

# File Upload
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret
```

**Frontend**
```env
VITE_API_URL=https://your-backend-domain.com/api
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable_key
VITE_GOOGLE_MAPS_API_KEY=your-google-maps-api-key
```

## Security Considerations

### 1. Environment Variables
- Never commit sensitive data to version control
- Use platform-specific environment variable management
- Rotate secrets regularly

### 2. HTTPS/SSL
- Always use HTTPS in production
- Configure SSL certificates
- Use HSTS headers

### 3. Database Security
- Use strong passwords
- Enable authentication
- Restrict network access
- Regular backups

### 4. API Security
- Implement rate limiting
- Use CORS properly
- Validate all inputs
- Monitor for suspicious activity

## Monitoring and Logging

### 1. Application Monitoring
```bash
# Install monitoring tools
npm install --save express-winston winston
```

### 2. Error Tracking
- **Sentry** for error tracking
- **LogRocket** for session replay
- **DataDog** for comprehensive monitoring

### 3. Performance Monitoring
- **New Relic** for APM
- **Pingdom** for uptime monitoring
- **Google Analytics** for user analytics

## Backup Strategy

### 1. Database Backups
```bash
# MongoDB backup
mongodump --uri="mongodb+srv://user:pass@cluster.mongodb.net/fooddelivery" --out=/backup/$(date +%Y%m%d)
```

### 2. Application Backups
- Regular code repository backups
- Environment configuration backups
- Media file backups (if applicable)

### 3. Automated Backups
```bash
# Cron job for daily backups
0 2 * * * /path/to/backup-script.sh
```

## Scaling Considerations

### 1. Horizontal Scaling
- Load balancers (Nginx, AWS ALB)
- Multiple server instances
- Database clustering

### 2. Vertical Scaling
- Increase server resources
- Optimize database queries
- Implement caching (Redis)

### 3. CDN Integration
- CloudFlare for global distribution
- AWS CloudFront
- Static asset optimization

## Deployment Automation

### GitHub Actions Example
```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '18'
          
      - name: Install dependencies
        run: npm install
        
      - name: Build application
        run: npm run build
        
      - name: Deploy to production
        run: |
          # Your deployment commands here
```

## Post-Deployment

### 1. Health Checks
- Verify all endpoints are working
- Test critical user flows
- Monitor error rates

### 2. Performance Testing
- Load testing with tools like Artillery
- Monitor response times
- Check database performance

### 3. User Acceptance Testing
- Test with real users
- Gather feedback
- Monitor user behavior

## Troubleshooting

### Common Deployment Issues

1. **Build Failures**
   - Check Node.js version compatibility
   - Verify all dependencies are installed
   - Review build logs for errors

2. **Database Connection Issues**
   - Verify connection string
   - Check network access rules
   - Confirm credentials

3. **CORS Errors**
   - Update CORS_ORIGIN environment variable
   - Check frontend API URL configuration

4. **SSL Certificate Issues**
   - Verify domain ownership
   - Check certificate expiration
   - Review DNS configuration

## Maintenance

### Regular Tasks
- [ ] Update dependencies monthly
- [ ] Monitor security vulnerabilities
- [ ] Review and rotate secrets
- [ ] Backup verification
- [ ] Performance optimization
- [ ] User feedback review

---

**Deployment complete!** Your FoodieExpress platform is now live and ready for users.

